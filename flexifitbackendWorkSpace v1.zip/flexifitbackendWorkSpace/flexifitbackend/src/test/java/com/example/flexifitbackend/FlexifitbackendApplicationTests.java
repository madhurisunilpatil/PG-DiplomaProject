package com.example.flexifitbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlexifitbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
