package com.example.flexifitbackend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.example.flexifitbackend.entity.User;
import com.example.flexifitbackend.repository.UserRepository;

@RestController
//@RequestMapping("/api/users")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
    
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
        // You might want to add password encryption here
        return userRepository.save(user);
    }
    
    @RequestMapping("/userreq")
    public void show() {
    	System.out.println(" get method called ");
    }
    
//    @PostMapping
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public void createUser(@RequestBody User user) {
        User savedUser = userRepository.save(user);
        System.out.println("insert success : "+ savedUser);
//        return new UserRepository(savedUser, HttpStatus.CREATED);
    }
    
}
