package com.example.flexifitbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.flexifitbackend.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
